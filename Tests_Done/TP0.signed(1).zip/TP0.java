
/* INTRODUZA OS SEUS DADOS (OBRIGATÓRIO PARA IDENTIFICAR o TESTE)
 * NUM MEC: 
 * NOME:
 * 103244
 * Gonçalo Lourenço da Silva
 * Programação I - Teste treino
 * JAM, 17-nov-2020
 * Cálculo do nº e valor das raízes reais de um polinómio de 2º 
 *   grau (Ax^2 + Bx + C = 0)num dado intervalo. 
 * SEM USAR a FORMULA RESOLVENTE. 
 * Solução: Raizes são os valores de x para os quais y é 0.
            Se y mudar de sinal relativamente ao ponto anterior
             temos um zero.
Resultados:
Introduza os coeficientes A, B, C do polinomio do 2grau:
A: 1
B: 3
C: 1
Introduza o intervalo Xinicial e Xfinal e o num de pontos:
xi:  -3
xf:  3
NPontos:  1000
Raiz 1 = -2.615616
Raiz 2 = -0.381381
Encontradas 2 raizes

 */
import java.util.Scanner;

public class TP0 {

    public static void main(String[] args) {

        //coeficientes do polinómio e intervalo
        double a, b, c, xi, xf; 
        //numero de pontos do intervalo
        int pontos;             

        System.out.println("Coeficientes A, B, C:");
        
        a = lerNumero("A: ", -1000, 1000);
        b = lerNumero("B: ", -1000, 1000);
        c = lerNumero("C: ", -1000, 1000);

        System.out.println("Intervalo e nº pontos:");
        xi = lerNumero("xi: ", -1000, 1000);
        xf = lerNumero("xf: ", -1000, 1000);
        pontos = (int)lerNumero("NPontos: ", 1, 100000);

        // Determinação das raízes
        RaizesPol2(a, b, c, xi, xf, pontos);
        
        // Teste da função f no intervalo [0, 2PI].
        double x1 = 0, x2 = Math.PI * 2;
        int np = 10;
        double[] y = new double [np];
        // chamada à função
        f(y, x1, x2, np);
        
        // ecreve pontos da função no ecrã
        for (int k = 0; k < y.length; k++)System.out.printf("%5.2f ",y[k]);
    }

    // 1) função para leitura de um valor real do teclado no
    //    intervalo [a, b]
    static double lerNumero(String mensagem, double a, double b) {
        Scanner ler = new Scanner(System.in);
         int n;
         do{
            System.out.print(mensagem);
            n = ler.nextInt();
         }while(n > b || n < a);
      
      return n;

    }

    // 2) função para cálculo das raízes de um polinómio do 2 
    //    grau. A função escreve no ecra as raizes encontradas 

    public static void RaizesPol2(double a, double b, double c,
                         double xi, double xf, int npontos) {
      double delta = (xf - xi)/(npontos - 1);
      double x = xi;
      double y0 = a * x * x + b * x + c;
      int nraizes = 1;
      for(int i = 0; i < npontos; i++){
         x += delta;
         double y = a * x * x + b * x + c;
         if((y0 > 0 && y <= 0) || (y0 < 0 && y >= 0)){
            System.out.printf("Raiz %d = %f \n", nraizes++, x);
         }
         y0 = y;
      }
      System.out.printf("Encontradas %d raizes \n", (nraizes - 1));


    }
    // função f 
    // deve devolver um array preenchido com n pontos da função y num dado intervalo [a, b]
    // y = sin (x + PI/4)
    // ....implemantar função f
   public static void f(double[] y, double x1, double x2, int npontos){
      double delta = (x2 - x1)/(npontos - 1);
      for(int x = 0; x < npontos; x++){
         y[x] = Math.sin(x1 + x * delta + Math.PI/4);
      }
   }


}