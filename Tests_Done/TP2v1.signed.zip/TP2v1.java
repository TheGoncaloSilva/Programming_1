
/* TP2 - sessão 1, 15 janeiro 2021		Duração 2H
 * NUMERO NOME:
 * 103244 Gonçalo Lourenço da Silva
 * Ler processar e guardar notas finais de uma turma de alunos.
 * Notas entre 0 e 5. Nota -1 é considerada uma FALTA.
 * Dados para cada aluno: id aluno, nota, nome aluno
*/
import java.util.Scanner;
import java.io.*;

public class TP2v1 {
  public static void main(String[] args) throws IOException {

    final int NALUNOS = 10;
    Aluno[] t = new Aluno[NALUNOS];
    t[0] = new Aluno(111,"maria.rita", 22);
    t[1] = new Aluno(12345,"oiii uiii", 3);
    t[2] = new Aluno(333,"xico ze", 3);
    t[3] = new Aluno(444,"manel", -1);
    int numAlunos = 4;
    numAlunos = lerTurma(t, numAlunos);

    System.out.printf("%nTurma:%n");
    imprimirTurma(t,numAlunos);
    // gravar turma, sem alunos com erros, num ficheiro
    filtrarTurma(t,numAlunos, "turma.txt");

    System.out.printf("%nFicheiro:%n");
    listarFicheiro("turma.txt");

    //imprime histograma
    imprimeHisto(histograma(t, numAlunos));
  }
  /* Alínea 1)
   * Testa se string s é composto só por letras maiúscula e minúsculas e espaços
   * e se tem pelo menos uma vogal e uma consoante.
   * Devolve true se for válido e false se for inválido
   */
  static boolean validarNome(String s) {
    boolean resultado = false;
   int vogal = 0, consoante = 0;
   boolean numero = false, white = true; // para saber se foi encontrado algum número ou algum caracter especial
   
   for(int i = 0; i <s.length();i++){
      char temp = s.charAt(i); // percorrer a string
      if(Character.isDigit(temp)){ //verificar se é número ou não, se existir um numero pode sair do ciclo
         numero = true;
         break;
      }else{
         if(Character.isLetter(temp)){ // verificar se é uma letra e não espaços ou caracteres especiais
            if("AEIOUaeiou".indexOf(temp) != -1){ // verificar se é vogal 
               vogal++;
            }else{ // se não for vogal é consoante
               consoante++;
            }
         }else if(!Character.isWhitespace(temp)){ // verificar se tem espaços a dividir vários nomes, se não tiver sai do ciclo
            white = false;
            break;
         }
      }
   }
   if(consoante > 0 && vogal > 0 && numero == false && white == true){ // verificar se houve pelo menos uma vogal ou consoante e se não houve nenhum numero ou caracter especial
      resultado = true; // se as verificações estiverem corretas
   }else{
      resultado = false; // se houver um número ou um caracter especial ou não houver uma consoante ou vogal
   }
    return resultado;
  }
  /* Alínea 2)
   * Ler dados de um aluno do teclado;
   * Ordem de leitura: id nota nome, tudo na mesma linha.
   * Se id == 0 acaba leitura, não lendo o resto dos campos.
   * Deve validar a nota, no intervalo [-1,5], e o nome. Repete a leitura se forem inválidos.
   * DEVE USAR a função validarNome() da alínea 1).
   * Devolve uma variável tipo Aluno.
   */
  static Aluno lerAluno() {
    Aluno a = new Aluno();
   Scanner sc = new Scanner(System.in); // scanner para ler o dados
   int id = 0;
   boolean verif = false; // verificação para saber se o nome está correto
   do{
      id = sc.nextInt();
      a.id = id; // guardar o valor do id numa variável, para saber se o utilizador pretendeu parar com a leitura
      if(id != 0){ // se o utilizador não quis parar com a leitura, continua
         int nota = sc.nextInt();
         String nome = sc.nextLine();
         if(nota >= -1 && nota <= 5){ // se a nota está dentro do intervalo
            verif = validarNome(nome); // se o nome está dentro das especificações desejadas
            if(verif){ // caso esteje tudo correto, pode ser guardado na class para ser introduzido no array
               a.id = id;
               a.nota = nota;
               a.nome = nome;
            }else{
               System.out.println("Erro, repita:"); // se houve um problema com a verificação do nome 
            }
         }else{
            System.out.println("Erro, repita:"); // se a nota não está dentro do intervalo
         }
      }
   }while(id != 0 && !verif); // se for introduzido 0 ou se a verificação for verdadeira sai
   
    return a;
  }

  /* Alínea 3)
   * Acrescenta alunos a uma turma de alunos (array t) com tamanho (num).
   * A leitura pára quando o ID do aluno for == 0 ou o array estiver cheio.
   * Devolve o número total de alunos no array (num + os novos).
   * DEVE USAR a função lerAluno() da alínea 2).
   */
  static int lerTurma(Aluno[] t, int num) {
    int nalunos = num;
   System.out.println("Introduza o ID(= 0 termina) NOTA NOME:");
   int id = 1; // id para validar se foi introduzido 0
   do{
      t[nalunos] = new Aluno(); // declarar a nova posição do array
      t[nalunos] = lerAluno(); // receber os dados do novo aluno e adicionálos ao novo array
      id = t[nalunos].id;
      
      if(id != 0){ // se o utlizador escolheu o 0, não terá nenhuns campos alterados no array, sendo assim não se incrementa o número de alunos
         nalunos++; // adicionado um novo aluno
      }
      
   }while(nalunos <= 10 && id != 0); // sai se for introduzido 0 ou se exceder o tamanho de 10 do array
    return nalunos;
  }
  /* Alínea 4)
   * Histograma de notas.
   * Argumentos são o array de Alunos (a) e o numero de alunos (num).
   * Devolve um array de inteiros,de 7 posições, com o histograma.
   * As notas estão no intervalo [0,5]; fora do intervalo ficam na posição 6.
   */
  static int[] histograma(Aluno[] a, int num) {
    int[] h = new int[0]; //deve fazer novo new com o comprimento adequado
   h = new int[7];  // declaração do novo tamanho
   for(int i = 0; i < num; i++){ // ciclo percorre até à posição correspondente do numero no array
      switch(a[i].nota){ // saber quais campos incrementar
         case 0: h[0]++;break;
         case 1: h[1]++;break;
         case 2: h[2]++;break;
         case 3: h[3]++;break;
         case 4: h[4]++;break;
         case 5: h[5]++;break;
         default : h[6]++;break; // se a nota é maior a 5 ou menor a 0, é uma nota inválida
      }
   }
    return h;
  }
  /* Alínea 5)
   * Escreve num ficheiro só os alunos com nome e nota válidos;
   * Sugestão: use a função alunoToString(); 
   * Se o segundo caracter do string for espaço o aluno é válido.
   */
  static void filtrarTurma(Aluno[] t, int n, String nomeF) throws IOException {
   File fout = new File(nomeF); // declarar o ficheiro
   PrintWriter pin = new PrintWriter(fout); // declarar que vou escrever no ficheiro
   
   for(int i = 0; i < n; i++){
      if(Character.isWhitespace(alunoToString(t[i]).charAt(1))){ // descobrir se o segundo caracter é espaço, de forma a saber se é válido
         pin.printf("%d %s %d \n", t[i].id, t[i].nome, t[i].nota); // escrever o conteúdo no ficheiro se for válido
      }
   }
   pin.close(); // fechar o ficheiro para forçar a guardar

  }
  /* Converte uma variável tipo Aluno (a) para um string: "erro id nome nota"
   * Validar o nome e a nota. erro = "e   " se aluno válido.
   * se nome inválido fica erro = "e1  "; se nota inválida fica erro = "e2  ";
   * se os dois forem inválidos fica erro = "e12 "; 
   */
  static String alunoToString(Aluno a) {
    String resultado = "  ";
    String erros = "e";
    if (!validarNome(a.nome)) erros += "1";
    if (a.nota <-1 || a.nota > 5)erros  = erros + "2";
    resultado = String.format("%-4s %5d %-15s %d", erros, a.id, a.nome, a.nota);
    return resultado;
  }
// Lista a turma no ecrã
  static void imprimirTurma(Aluno[] t, int n) {
    if (n < 0 || n > t.length)n = t.length;	//Testa limites array
    System.out.println("Erro    ID Nome           Nota");
    for (int a = 0; a < n; a++) {
      System.out.println(alunoToString(t[a]));
    }
  }
// Lista ficheiro no ecrã
  static void listarFicheiro(String nomeF) throws IOException {
    File turma = new File(nomeF);
    if (turma.exists()) {
      Scanner f = new Scanner(turma);
      while (f.hasNextLine()) {
        System.out.println(f.nextLine());
      }
      f.close();
    }
  }
//Imprime histograma
  static void imprimeHisto(int[] hist) {
    System.out.printf("%nHistograma:%nNota Freq%n");
    for (int i = 0; i < hist.length; i++) {
      System.out.printf("%3d: %4d%n",i,hist[i]);
    }
  }
}
//classes
class Aluno {
  int id;	// numero do aluno
  String nome;	// nome do alunos
  int nota;	// nota final do aluno de 0 a 5; valor 6 identifica faltas
  // construtores
  Aluno() {}
  Aluno(int id, String n, int nota) {
    this.id = id;
    this.nome = n;
    this.nota = nota;
  }
}